package org.elsys.page;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.PatternSyntaxException;

public class Site {
	public static void main(String[] args) {

		//Site code
		try {
            URL url = new URL("http://www.elsys-bg.org");
            Page p = new Page(url);
           
            //URL protocol
    		System.out.println("Protocol: "+ url.getProtocol());
    		
    		//Download content 
    		p.pages();
    		
    		//links
    		String HTMLPage;
    		PatternSyntaxException linkPattern = Pattern.compile("(<a[^>]+>.+?</a>)",  Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
    		Matcher pageMatcher = linkPattern.matcher(HTMLPage);
    		ArrayList<String> links = new ArrayList<String>();
    		while(pageMatcher.find()){
    		    links.add(pageMatcher.group(1));
    		}
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } 
		
	}
}
