package org.elsys.page;

public class Link {

}
