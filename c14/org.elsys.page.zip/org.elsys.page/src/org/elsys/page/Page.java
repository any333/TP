package org.elsys.page;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

public class Page {
	private URL url; 
	public Page(URL input_url) {
		url = input_url;
	}
	
	public void pages() {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					url.openStream()));
			BufferedWriter writer = new BufferedWriter(new FileWriter(
					"data.html"));

			String line;
			while ((line = reader.readLine()) != null) {
				
				writer.write(line);
				writer.newLine();
			}

			reader.close();
			writer.close();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
